# TODO: remove in 3.0, kept for backward compatibility
from .cli import main  # noqa: F401, pylint: disable=unused-import
